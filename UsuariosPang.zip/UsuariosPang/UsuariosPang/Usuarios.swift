//
//  Usuarios.swift
//  UsuariosPang
//
//  Created by Ernesto Pang on 10/13/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import Foundation

struct Usuarios{
    var nameOfUsuario: String
    var password: String
    var estado: Bool 
}

